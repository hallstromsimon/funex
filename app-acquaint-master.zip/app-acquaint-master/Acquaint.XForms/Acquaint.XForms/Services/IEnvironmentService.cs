﻿namespace Acquaint.XForms
{
    public interface IEnvironmentService
    {
        bool IsRealDevice { get; }
    }
}

